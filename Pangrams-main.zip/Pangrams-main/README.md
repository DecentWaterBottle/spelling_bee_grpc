# Pangrams
Rough script to create a pangram list (see NY Times Spelling Bee App) and select one at random
